@include('Admin.bin.header')
<div class="container">
    <h1 class="text-center mt-4">Add Product</h1>
    <form action="{{url('add-product')}}" method="post" enctype="multipart/form-data">
        @csrf>
        <div class="mb-3">
            <label for="product_name" class="form-label">Product Name</label>
            <input type="text" class="form-control" id="productName" name="product_name"
                placeholder="Enter product name">
        </div>
        <div class="mb-3">
            <label for="product_Description" class="form-label">Product Description</label>
            <textarea class="form-control" id="productDescription" name="product_Description" rows="3"></textarea>
        </div>
        <div class="mb-3">
            <label for="product_Price" class="form-label">Product Price</label>
            <input type="number" class="form-control" id="productPrice" name="product_price"
                placeholder="Enter product price">
        </div>
        <div class="mb-3">
            <label for="product_Image" class="form-label">Product Image</label>
            <input type="file" class="form-control" id="productImage" name="product_image">
        </div>
        <div class="mb-3">
            <label for="Status_Product" class="form-label">Product Product</label>
            <select class="form-select" id="StatusProduct" name="status">
                <option value="electronics">active</option>
                <option value="fashion">inactive</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Add Product</button>
    </form>
</div>


@include('Admin.bin.footer')