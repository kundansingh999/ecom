@include('frontend.bin.pageheader')

     <div class="container mt-4">
         <h4  class="pb-4">Mens Wear Collection</h4>
         <div class="row row-cols-1 row-cols-md-4 g-4">
             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\shirt.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\shirt.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\shirt.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\shirt.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>


         </div>


     </div>

     <div class="container pt-4">
         <h4>Women Fashion Best Collection</h4>
         <div class="row row-cols-1 row-cols-md-4 g-4">
             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\w1.webp')}}" class="card-img-top" alt="..." style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\w2.webp')}}" class="card-img-top" alt="..." style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\women kurti.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\women saree.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

         </div>


     </div>


     <div class="container pt-4">
         <h4>Kids Wear Fashion Best Collection </h4>
         <div class="row row-cols-1 row-cols-md-4 g-4">
             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\kids wear.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\kids wear.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\kids wear.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>

             <div class="col">
                 <div class="card ">
                     <img src="{{asset('assets\img\kids wear.webp')}}" class="card-img-top" alt="..."
                         style="height: 250px;">
                     <div class="card-body text-center">
                         <h5 class="card-title">Shirt</h5>
                         <p class="card-text">Sparky T-shirt</p>
                         <h4 class="card-text">₹500</h4>
                         <button type="button" class="btn btn-primary">Order Now</button>
                     </div>
                 </div>
             </div>









         </div>


     </div>

@include('frontend.bin.footer')