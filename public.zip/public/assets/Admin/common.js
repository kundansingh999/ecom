$(document).ready(function () {
    $(document).on('click', '.category-delete', function () {
        $('.virat').val($(this).data('id'));
        
 
    });

});